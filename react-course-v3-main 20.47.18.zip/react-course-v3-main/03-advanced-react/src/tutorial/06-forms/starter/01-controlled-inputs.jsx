const ControlledInputs = () => {
  return <h2>Controlled Inputs</h2>;
};
export default ControlledInputs;
