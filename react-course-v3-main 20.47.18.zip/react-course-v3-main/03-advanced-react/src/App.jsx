function App() {
  return (
    <div className='container'>
      <h2>Advanced React</h2>
    </div>
  );
}

export default App;
