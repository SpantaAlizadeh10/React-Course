const UseStateBasics = () => {
  return <h2>useState basics</h2>;
};

export default UseStateBasics;
