const App = () => {
  return <h2>Sidebar Starter</h2>;
};
export default App;
