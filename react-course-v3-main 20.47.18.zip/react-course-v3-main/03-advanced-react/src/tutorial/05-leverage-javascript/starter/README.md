In this section, we will create all files from scratch.
